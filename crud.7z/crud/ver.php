<?php session_start();

if(!isset($_SESSION['valid'])){
    header('Location: login.php');
}

// Incluir oarquivo de conexão ao banco dde dados:
include_once("conexao.php");

//Buscar os dados em ordem descendente (entrada mais recente pimeiro)
$sql = "SELECT * FROM produtos
WHERE login_id=".$_SESSION['id']." ORDER BY id DESC";

$resultado = mysqli_query($strcon, $sql);
?>

<DOCTYPE html>
<html lang="pt-br">
<head>
    <title>ConSULTA pRODUTOS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale-1">
    <link href="estilo.css">
</head>

<body>
    <a href="index.php">Inicio</a> | <a href="add.html">Adicionar Produtos</a> |
    <a href="logout.php">Logout</a>
    <br><br>

    <table width='80%' border=0>
        <tr bgcolor='#CCCCCC'>
            <td>Nome</td>
            <td>Quantidade</td>
            <td>Preco (R$)</td>
            <td>Atualizar</td>
        </tr>
        <?php
        while($res =mysqli_fetch_array($resultado)){
            echo"<tr>";
            echo "<td>".$res['nomeProduto']."</td>";
            echo "<td>".$res['qtd']."</td>";
            echo "<td>".$res['preco']."</td>";
            echo "<td><a href=\"editar.php?id=$res[id]\">Editar</a> | <a href=\"excluir.php?id=$res[id]\"onClick=\"return confirm('Tem certeza de que você deseja excluir?')\">Excluir</a></td>";
        }
        ?>
    </table>
<body>
<html>