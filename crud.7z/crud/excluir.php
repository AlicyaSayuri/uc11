<?php session_start(); 

if(isset($_SESSION['valid'])) {
    header('Location: login.php');
}

//Incluir o arquivo de conexão ao banco de dados
include("conexao.php");

//Obter o id dos dados a partir da URL
$id = $_GET['id'];

//Excluir a linha da tabela 
$sql= "DELETE FROM produtos WHERE id = '$id'";
$resultado = mysqli_query($strcon,$sql);

//Redirecionar para a página de consulta -> ver.php
header("Location:ver.php");
?>
