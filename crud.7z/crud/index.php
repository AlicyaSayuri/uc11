<?php session_start(); ?>
<html lang="pt-br">
<head>
    <title>Homepage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <link href="stilo.css" rel="styleheet" type="text/css">
</head>

<body>
    <div id="header">
        Bem-Vindo à nossa loja virtual!
    </div>
    <?php
    if(isset($_SESSION['valid'])){
        include("conexao.php");
        $result = mysqli_query($strcon, "SELECT * FROM cadastro");
    ?>
        bem vindo <?php echo $_SESSION['name'] ?> ! <a href='logout.php'>logout</a><br>
        <br>
        <a href='ver.php'>Visualizar e Adicionar Produtos</a>
        <br><br>
        <a href='editarCadastro.php'>Alterar Cadastro</a>
        <br><br>
    <?php
    }
    else{
        echo "Você precisa estar logado para visualizar o conteudo.<br><br>";
        echo "<a href='login.php'>Login</a> | <a href='registrar.php'>Registrar-se</a>";
    }
    ?>
    <div id="footer">
        Desenvolvido por: <a href="http://www.bosontreinamentos.com.br">Fabio dos Reis</a>
    </div>
</body>
</html>