<?php session_start(); 

if(!isset($_SESSION['valid'])) {
    header('location: login.php');
}

// Incluir o arquivo de conexão ao bnco de dados
include_once("conexao.php");

if(isset($_POST['update']))
{
    $id= $_POST['id'];
    $nome= $_POST['nome'];
    $qtd= $_POST['qtd'];
    $preco= $_POST['preco'];

    //Verificando se há campos vazios:
    if(empty($nome) || empty($qtd) || empty($preco)) {
        if(empty($nome)){
             echo "<font color='red>Campo Nome está vazio. </font><br>";
        }

        if(empty($qtd)){
            echo "<font color='red>Campo Quantidade está vazio. </font><br>";
        }

        if(empty($preco)){
            echo "<font color='red>Campo Preço está vazio. </font><br>";
        }
    } else {
        //Atualizar a tabela
        $sql= "UPDATE produtos SET nomeProduto='$nome',qtd='$qtd', preco='$preco' WHERE id =$id";
        $resultado = mysqli_query($strcon,$sql);

        //Redirecionar para a pagina de visualização -> ver.php
        header("Location: ver.php");
    }
}

//Obter id a partir da URL enviada
$id = $_GET['id'];

//Selecionar dados associados com o id em particular:
$sql = "SELECT * FROM produtos WHERE id=$id";
$consulta = mysqli_query($strcon, $sql);

while($res = mysqli_fetch_array($consulta))
{
    $nome = $res['nomeProduto'];
    $qtd = $res['qtd'];
    $preco = $res['preco'];
}
?>

<html lang="pt-br">
<head>
    <title>Alterar Produtos</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <link href="estilo.css" rel="styleheet" type="text/css">
</head>
<body>
    <a href="index.php">Home</a>
    <a href="ver.php">Ver Produtos</a>
    <a href="logout.php">Logout</a>
    <b><b>
        <form name="atualizaProdutos" method="post" action="editar.php">
            <table border="0">
                <tr>
                <td>Nome</td>
                    <td><input type="text" name="nome"value="<?php echo $nome;?>"></td>
                </tr>
                <tr>
                    <td>Quantidade</td>
                    <td><input type="text" name="qtd"value="<?php echo $qtd;?>"></td>
                </tr>
                <tr>
                    <td>Preço</td>
                    <td><input type="text" name="preco" value="<?php echo $preco;?>"></td>
                </tr>
                <tr>
                    <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                    <td><input type="submit" name="update" value="Atualizar"></td>
                </tr>
            </table>
        </form>
    </body>
</html>