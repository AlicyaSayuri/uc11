<?php session_start(); 

if(!isset($_SESSION['valid'])){
    header('location: login.php');
}
?>

<html lang="pt-br">
<head>
    <title>Adicionar Dados</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <link href="estilo.css">
</head>

<body>
<?php
include_once("conexao.php");

if(isset($_POST['Submit'])) {
    $nome = $_POST['nome'];
    $qtd = $_POST['qtd'];
    $preco = $_POST['preco'];
    $loginId = $_SESSION['id'];

    //Verificar se há campos vazios
    if(empty($nome) || empty($qtd) || empty($preco)) {

        if(empty($nome)){
            echo "<font color='red>Campo Nome está vazio. </font><br>";
        }

        if(empty($qtd)){
            echo "<font color='red>Campo Quantidade está vazio. </font><br>";
        }

        if(empty($preco)){
            echo "<font color='red>Campo Preço está vazio. </font><br>";
        }

        //Link para a página anterior
        echo "<br/><a href='javascript:self.history.back();'>Voltar</a>";

    }
    else {
        //Se todos os campos estiverem preenchidos (não-vazios)

        //Inserir os dados no banco de dados 
        $sql="INSERT INTO produtos(nomeProduto, qtd, preco, login_id)
        VALUES('$nome', '$qtd', '$preco','$loginId')";

        $result = mysqli_query($strcon,$sql);

        //Mostrar mensagem de sucesso na operação
        echo"<font color='green'> Dados adicionados com sucesso";
        echo"<br><a href='ver.php'>Ver Produtos</a>";
    }

}
?>
</body>
</html>

