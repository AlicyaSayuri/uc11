<?php

$servidor = 'localhost';
$nomeBanco = 'db_loja';
$usuario = 'sayuri';
$senha = '123';

$strcon = mysqli_connect($servidor, $usuario, $senha, $nomeBanco);

/* O usuario deve ser criado do phpadmin na aba privilegios, adicionar conta de utilizador, 
preencher os campos nome de utilizador, palavra-passe e confirma. este é do MySQL, não de aplicação!*/

?>