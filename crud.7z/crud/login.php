<?php session_start(); ?>
<html lang="pt-br">
<head> 
<title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <link href="estilo.css" rel="styleheet" type="text/css">
</head>

<body>
<a href="index.php">Página Inicial</a><br>
<?php
include("conexao.php");

if(isset($_POST['submit'])){
    $user = mysqli_real_escape_string($strcon, $_POST['username']);
    $senha = mysqli_real_escape_string($strcon, $_POST['password']);

    if($user == "" || $senha == "") {
        echo "Nome de usuário ou senha vazios.";
        echo "<a href='login.php'>Voltar</a>";
    } else{
        $sql = "SELECT * FROM cadastro WHERE Usuario='$user'";
        $res = mysqli_query($strcon, $sql)
                    or die("Impossivel executar a consulta solicitada.");

        $linha = mysqli_fetch_assoc($res);

        //Verificar senha criptografada
        $senhaOK = password_verify($senha, $linha['senha']);

        if(is_array($linha) && !empty($linha) && $senhaOK) {
            $validuser = $linha['usuario'];
            $_SESSION['valid'] = $validuser;
            $_SESSION['name'] = $linha['nome'];
            $_SESSION['id'] = $linha['id'];
        } else{
            echo "Nome de ususario ou senha inválido.<br>";
            echo "<a href='login.php'>Voltar</a>";
        }

        if(isset($_SESSION['valid'])) {
            header('Location: index.php');
        }

    }
} else {
?>
    <p><font size="+2">Login</font></p>
    <form name="login" method="POST" action="">
        <table width="75%" border="0">
            <tr>
                <td width="10">Nome de Usuario</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td width="10%">Nome de usuario</td>
            </tr>
            <tr>
                <td>Senha</td>
                <td><input type="password" name="password">
            </tr>
            <tr>
                <td>&nbsp;<td>
                <td><input type="submit" name="submit" value="Entrar"></td>
            </tr>
        </table>
    </form>
<?php
}
?>
</body>
</html>



