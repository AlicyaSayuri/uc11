<?php session_start(); 

if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}

$login_id= $_SESSION['id'];

include_once("conexao.php");

if(isset($_POST['update']))
{
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $hashsenha = trim(password_hash($_POST['senha'], PASSWORD_DEFAULT));


    //Verificar se há campos vazios:
    if(empty($nome) || empty($email) || empty($senha)) {

        if(empty($nome)) {
            echo "<font color='red'>Falta seu nome.</font><br/>";
        }
        if(empty($email)) {
            echo "<font color='red'>Falta seu e-mail.</font><br/>";
        }
        if(empty($senha)) {
            echo "<font color='red'>Senha não informada.</font><br/>";
        }
    }
    else{
        //Atualizar a tabela 
        $sql = "UPDATE cadastro SET nome='$nome', email='$email', senha='$hashsenha' WHERE id=$login_id";
        $result = mysqli_query($strcon,$sql);

        //Alterar array $_SESSION para exibir um novo valor ao carregar página inicial
        $_SESSION['name'] = $nome;

        // Redirecionar para a página inicial
        header("Location: index.php");
    
    }
}
//Selecionar dados acossiadps com id em particular:
$result =  mysqli_query($strcon, "SELECT * FROM cadastro WHERE id=$login_id");

while($res = mysqli_fetch_array($result))
{
    $nome= $res['nome'];
    $usuario = $res['usuario'];
    $email = $res['email'];
    $foto = $res['foto'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Editar Cadastro</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <link href="estilo.css" rel="styleheet" type="text/css">
</head>
<body>
    <a href="index.php">Home</a>
    <a href="ver.php">Ver Produtos</a>
    <a href="logout.php">Logout</a>
    <br><br>
        <img src="<?php if(empty($foto)){echo "imagens/OIP.jfif";} else{echo $foto;}?>" width='150' height='150'><br>

        <form name="editarCadastro" method="POST" action="editarCadastro.php">
            <table border="0">
            <tr>
                <td>Usuario</td>
                    <td><?php echo $usuario;?></td>
                </tr>
                <tr>
                    <td>Nome</td>
                    <td><input type="text" name="nome"value="<?php echo $nome;?>"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" value="<?php echo $email;?>"></td>
                </tr>
                <tr>
                    <td>Senha</td>
                    <td><input type="password" name="senha" required></td>
                </tr>
                <tr>
                    <td><input type="submit" name="update" value="Atualizar"></td>
                </tr>
            </table>
        </form>
</body>
</html>





    