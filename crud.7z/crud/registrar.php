<html lang="pt-br">
<head>
    <title>Registrar-se</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="estilo.css">
</head>
 
<body>
<a href="index.php">Página Inicial</a><br>
 
<?php
include("conexao.php");
 
if(isset($_POST['submit'])) {
 
    // --------------FOTO DO USUÁRIO ------------------
    // Obter nome do arquivo e nome temporário
    $arquivoImagem = $_FILES["arquivo"]["name"];
    $arquivoTemp = $_FILES["arquivo"]["tmp_name"];
    // Criar a pasta imagens antes no servidor:
    $caminhoImagem = "imagens/".$arquivoImagem;
 
    // Tamanho da imagem enviada:
    $tamImagem= $_FILES['arquivo']['size'];
    // Tamanho máximo a ser enviado:
    define("TAM_MAX", 2*1024*1024);
 
    // Descobrir o tipo MIME do arquivo enviado
    $tipoArquivo = $_FILES['arquivo']['type'];
    // Tipos de arquivo que serão permitidos:
    $permitido = array("image/jpeg", "image/gif", "image/png");
 
    // flag para verificar se imagem já existe:
    $uploadOK = 1;
 
    // Verificar se o arquivo de imagem já existe
    if (file_exists($caminhoImagem)) {
        echo "Imagem já cadastrada.<br>";
        $caminhoImagem = NULL;
        $uploadOk = 0;
        // TODO: gerar nome aleatório para imagem para obter nome sempre único
    }
    else if ($tamImagem > TAM_MAX) { // Limitar tamanho da imagem em 2 MB
        $msg = "Imagem muito grande. Deve ter menos de 5MB";
        $caminhoImagem = NULL;
        $uploadOk = 0;
        echo '<script type="text/javascript">alert("'.$msg.'");</script>';
    }
    else if(!in_array($tipoArquivo, $permitido)) {
        $msg = 'Somente são permitidos arquivos de imagem jpg, gif e png.';
        $caminhoImagem = NULL;
        $uploadOk = 0;
        echo '<script type="text/javascript">alert("'.$msg.'");</script>';
    }
    // Mover a imagem para a pasta de imagens do servidor
    else if (move_uploaded_file($arquivoTemp, $caminhoImagem) && $uploadOK) {
        $msg = "Imagem enviada com sucesso!<br>";
    }
    else{
        $msg = "Falha ao enviar imagem ao servidor<br>";
    }
    // --------------FIM FOTO DO USUÁRIO ------------------
 
    $nome = $_POST['name'];
    $email = $_POST['email'];
    $user = $_POST['username'];
    $senha = $_POST['password'];
 
    if($user == "" || $senha == "" || $nome == "" || $email == "") {
        echo "Todos os campos devem ser preenchidos. Um ou mais campos estão vazios.";
        echo "<br>";
        echo "<a href='registrar.php'>Voltar</a>";
    }
    else {
        $hashsenha = trim(password_hash($senha, PASSWORD_DEFAULT)); // criptografa senha com algoritmo bcrypt
        $sql = "INSERT INTO cadastro(Nome, Email, Usuario, Senha, foto) VALUES('$nome', '$email', '$user', '$hashsenha', '$caminhoImagem')";
        mysqli_query($strcon, $sql) or die("Não é possível executar a consulta solicitada.");
        echo "Registro efetuado com sucesso!<br>";
        echo "<a href='login.php'>Login</a>";
    }
}
else {
?>
    <p><font size="+2">Registrar</font></p>
    <form name="cadastro" method="POST" action="" enctype="multipart/form-data">
        <table width="75%" border="0">
            <tr>
                <td width="10%">Nome Completo</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="email"></td>
            </tr>          
            <tr>
                <td>Nome de usuário</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>Senha</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td>Selecionar Foto:</td>
                <td><input type="file" name="arquivo" id="arquivo"/></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Registrar"></td>
            </tr>
        </table>
    </form>
<?php
}
?>
</body>
</html>