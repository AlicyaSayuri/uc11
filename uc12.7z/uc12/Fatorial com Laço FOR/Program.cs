﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fatorial_com_Laço_FOR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, fat, cont;
            n = 0;
            fat = 1;

            Console.WriteLine("Digite um número: ");
            n = int.Parse(Console.ReadLine());

            if (n < 0)
            {
                Console.WriteLine("O número não pode ser negativo! ");
            }
            else if ((n == 0) || (n == 1) )
            {
                Console.WriteLine("Fatoração de {0} é 1", n);
            }
            else
            {
                for (cont = n; cont >= 1; cont--) 
                {
                    fat *= cont;
                }
                Console.WriteLine("O resultado da fatoração de {0} é {1}", n, fat); 
            }

            Console.ReadLine();

            
        }
    }
}
