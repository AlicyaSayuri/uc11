﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Arrays
            /* Sintaxe:
             tipo[] nomeArray = new tipo[tamanho];
            */

            // Exemplo: Array de 6 posições para números inteiros
            int[] numerosLoteria = new int[6];

            // Preencher array na inicilização
            int[] numeros01 = new int[5] { 2, 6, 9, 0, 4 };

            // Outra forma de preencher na inicialização
            int[] numeros02 = { 2, 6, 9, 0, 4 };

            //Acessar um elemento do array
            int valor;
            valor = numeros01[2];
            Console.WriteLine("Item na posição 2 do array: {0}", numeros01[2]);
            Console.WriteLine("Item na posição 2 do array: {0}", valor);

            // Alterar conteúdo do array
            numeros01[2] = 16;
            Console.WriteLine("Item na posição 2 do array: {0}", numeros01[2]); 

            // Iterar pelos elementos do array
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(numeros01[i].ToString());
            }

            // Iterar pelos elementos do array com foreach
            foreach (int item in numeros01)
            {
                Console.WriteLine(item.ToString());
            }

            Console.ReadLine();
        }
    }
}
