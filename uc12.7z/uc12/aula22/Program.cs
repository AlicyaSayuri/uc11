﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Atividade - investimento
            int N1;
            double N2;

            Console.Write("Digite o valor investido: ");
            N1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Quantos % de juros no mês: ");
            N2 = Convert.ToDouble(Console.ReadLine());


    
        }
    }
}
