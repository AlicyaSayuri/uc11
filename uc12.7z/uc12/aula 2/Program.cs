﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1;
            double num2;

            // Declaração e inicializção de variáveis
            Console.Write("Digite um número: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Digite outro número: ");
            num2 = Convert.ToDouble(Console.ReadLine());



            //Cálculo e exibição de resultados
            double soma = num1 + num2;
            Console.WriteLine("Soma: " + soma.ToString());
            Console.WriteLine("Subratação: {0}", (num1 - num2).ToString());
            Console.WriteLine("Multiplicação: {0}", (num1 * num2).ToString());
            Console.WriteLine("Divisão: " + (num1 / num2).ToString("N3"));
            Console.WriteLine("Módulo: " + (num1 % num2).ToString());
            
            // Exponenciação: num1 elevado ao quadrado
            double potencia;
            potencia = Math.Pow(num1, 2);
            Console.WriteLine("Potencia: {0}", potencia.ToString());
           
            // Conversão do String em Inteiro
            string valor1 = "25"; // variavel declarada como string
            int num3 = Int32.Parse(valor1);
            int resultado = num3 * 2;
            Console.WriteLine("\nResultado: {0}", resultado.ToString());

            Console.ReadLine();

        }
    }
}