﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace condicionais
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Digite o primeiro número: ");
            num1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo número: ");
            num2 = Int32.Parse(Console.ReadLine());

            // Usar condicional para comparação dos valores
            if (num1 == num2)
            {
                Console.WriteLine("Os números são iguais!");
            }

            else
            {
                Console.WriteLine("Os números são diferentes...");
            }

            Console.ReadLine();

        }
    }
}
