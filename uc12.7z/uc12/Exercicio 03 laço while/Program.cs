﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_03_laço_while
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string Nome, Sobrenome, Data;

            Console.WriteLine("clique em enter para iniciar");
            while (Console.ReadKey().Key != ConsoleKey.Q) 
            {
                Console.Write("Digite seu nome: ");
                Nome = Console.ReadLine();

                Console.Write("Digite seu sobrenome: ");
                Sobrenome = Console.ReadLine();

                Console.WriteLine("Digite sua data de nascimento: ");
                Data = Console.ReadLine();

                Console.Clear();

                Console.WriteLine("Presssione a tecla q para sair.");
                Console.WriteLine("Deseja cadastrar outro usuário? ");
                
            }
            Console.ReadLine();

        }
        
    }
}
