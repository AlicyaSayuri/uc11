﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Exercicio_01_Laço_while
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            int num;

            Console.Write("Digite um número: ");
            
            num = Convert.ToInt32(Console.ReadLine());

            if (num <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Erro!!! Não pode ser um número menor que zero ou negativo. ");
                
            }
            else
            {
                
            }

            while (i <= num)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(i.ToString());
                i++;
            }

            Console.ReadLine();
      
        }
    }
}
