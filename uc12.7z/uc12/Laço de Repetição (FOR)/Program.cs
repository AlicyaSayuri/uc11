﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laço_de_Repetição__FOR_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // laço for de repetição
            for (int i = 1; i <= 1000; i++)
            {
                Console.WriteLine(i.ToString());
            }

            Console.ReadLine();
        }
    }
}
