﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_de_repetição_laço_while_encerramento_com_0
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string Nome, Sobrenome, Codigo;
           

            Console.WriteLine("Verificação de usúarios.");

            
            while (Console.ReadKey().Key != ConsoleKey.NumPad0)

            {
                Console.WriteLine("Digite seu código de verificação");
                Codigo = Console.ReadLine();
               

                Console.WriteLine("Digite seu nome: ");
                Nome = Console.ReadLine();

                Console.WriteLine("Digite seu sobrenome: ");
                Sobrenome = Console.ReadLine();

                Console.Clear();

                Console.WriteLine("Cadastre outro usúario: ");
   
            }

            Console.ReadLine();
        }
    }
}
