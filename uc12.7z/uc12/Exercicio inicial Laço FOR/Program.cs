﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_inicial_Laço_FOR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int num;

            // laço for de repetição
            for (int i = 150; i <= 500; i++)
            {
                num = i%2;
                if (num%2 == 0)
                Console.WriteLine(num);
            }

            Console.ReadLine();
        }
    }
}
