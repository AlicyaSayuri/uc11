﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade_criando_os_controles__design_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClicar_Click(object sender, EventArgs e)
        {
            txtSaida.Focus();
        }

        private void txtEntrada_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEntrada_KeyDown(object sender, KeyEventArgs e)
        {
            // Esse funciona no evento KeyDown, sem precisar de conversão de tecla, com propriedade KeyCode.
            if (e.KeyCode == Keys.Enter)
            {
                txtSaida.Focus();
            }
        }

        private void btnComprimento_Click(object sender, EventArgs e)
        {
            string texto = txtEntrada.Text;
            MessageBox.Show("Comprimento da String: " + texto.Length.ToString());
        }
    }
}
