﻿namespace atividade_criando_os_controles__design_
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEntrada = new System.Windows.Forms.Label();
            this.txtEntrada = new System.Windows.Forms.TextBox();
            this.txtSaida = new System.Windows.Forms.TextBox();
            this.btnClicar = new System.Windows.Forms.Button();
            this.btnComprimento = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEntrada
            // 
            this.lblEntrada.AutoSize = true;
            this.lblEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntrada.Location = new System.Drawing.Point(27, 68);
            this.lblEntrada.Name = "lblEntrada";
            this.lblEntrada.Size = new System.Drawing.Size(234, 20);
            this.lblEntrada.TabIndex = 0;
            this.lblEntrada.Text = "Digite uma palavra ou frase:";
            // 
            // txtEntrada
            // 
            this.txtEntrada.Location = new System.Drawing.Point(31, 106);
            this.txtEntrada.Name = "txtEntrada";
            this.txtEntrada.Size = new System.Drawing.Size(230, 20);
            this.txtEntrada.TabIndex = 1;
            this.txtEntrada.TextChanged += new System.EventHandler(this.txtEntrada_TextChanged);
            this.txtEntrada.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntrada_KeyDown);
            // 
            // txtSaida
            // 
            this.txtSaida.Location = new System.Drawing.Point(31, 196);
            this.txtSaida.Name = "txtSaida";
            this.txtSaida.Size = new System.Drawing.Size(230, 20);
            this.txtSaida.TabIndex = 2;
            // 
            // btnClicar
            // 
            this.btnClicar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnClicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClicar.Location = new System.Drawing.Point(357, 68);
            this.btnClicar.Name = "btnClicar";
            this.btnClicar.Size = new System.Drawing.Size(126, 67);
            this.btnClicar.TabIndex = 3;
            this.btnClicar.Text = "Muda Foco";
            this.btnClicar.UseVisualStyleBackColor = false;
            this.btnClicar.Click += new System.EventHandler(this.btnClicar_Click);
            // 
            // btnComprimento
            // 
            this.btnComprimento.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnComprimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComprimento.Location = new System.Drawing.Point(357, 172);
            this.btnComprimento.Name = "btnComprimento";
            this.btnComprimento.Size = new System.Drawing.Size(126, 67);
            this.btnComprimento.TabIndex = 4;
            this.btnComprimento.Text = "Comprimento da String";
            this.btnComprimento.UseVisualStyleBackColor = false;
            this.btnComprimento.Click += new System.EventHandler(this.btnComprimento_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnComprimento);
            this.Controls.Add(this.btnClicar);
            this.Controls.Add(this.txtSaida);
            this.Controls.Add(this.txtEntrada);
            this.Controls.Add(this.lblEntrada);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEntrada;
        private System.Windows.Forms.TextBox txtEntrada;
        private System.Windows.Forms.TextBox txtSaida;
        private System.Windows.Forms.Button btnClicar;
        private System.Windows.Forms.Button btnComprimento;
    }
}

