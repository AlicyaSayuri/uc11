﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laço_for_de_repetição_do_while
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Laço for de repetição DO
            /*
            No laço do, o teste lógico é realizado APÓS a primeira execução do bloco de código a ser repetido, garantindo
            asi, que esse bloco seja executado ao menos uma vez, de forma distinta do laço while, no qual o teste é realizado 
            no INÍCIO (antes do bloco de códigos).
            */

            int i = 1;

            do
            {
                Console.WriteLine(i * 2);
                i++;
            }
            while (i <= 20);

            Console.ReadLine();
            
        }
    }
}
