﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laço_repeticão_while__cor_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string cor;
            Console.WriteLine("Pressione enter para iniciar: ");
            while(Console.ReadKey().Key != ConsoleKey.X)
            {
                Console.Clear();
                Console.WriteLine("Digite uma cor: ");
                cor = Console.ReadLine();
                Console.WriteLine("A cor esolhida foi {0}", cor);

                Console.WriteLine("Digite qualquer tecla para continuar:");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("Deseja escolher uma outra cor?");
                Console.WriteLine("x para sair ou outra tecla para continuar.");
            }

            Console.ReadLine();
        }
    }
}
