﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_condicional_encadeado_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float n1, n2, n3, n4, media;

            Console.WriteLine("Digite a primeira nota ");
            n1 = float.Parse(Console.ReadLine());

            Console.WriteLine("Digite a segunda nota ");            
            n2 = float.Parse(Console.ReadLine());

            Console.WriteLine("Digite a  terceira nota ");
            n3 = float.Parse(Console.ReadLine());

            Console.WriteLine("Digite a  quarta nota ");
            n4 = float.Parse(Console.ReadLine());


            media = (n1 + n2 + n3 + n4) / 4;

            if (media >= 7)
            {
                Console.WriteLine("Aluno Aprovado!");
            }

            else if (media >= 5) 
            {
                Console.WriteLine("Ficou de Recuperação.");
            }

            else 
            {
                Console.WriteLine("Aluno Reprovado!");
            }

            Console.ReadLine();

        }
    }
}
