﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace condicional_encadeado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int diaSemana;
            string nome;

            Console.WriteLine("Digite o dia da semana, 1 a 7: ");
            diaSemana = Int32. Parse(Console.ReadLine());

            if (diaSemana == 1)
            {
                nome = "Domingo";
            }
            else if (diaSemana == 2)
            {
                nome = "Segunda";
            }
            else if (diaSemana == 3)
            {
                nome = "Terça-Feira";
            }
            else if (diaSemana == 4)
            {
                nome = "Quarta-Feira";
            }
            else if (diaSemana == 5)
            {
                nome = "Quinta-Feira";
            }
            else if (diaSemana == 6) 
            {
                nome = "Sexta-Feira";
            }
            else if (diaSemana == 7)
            {
                nome = "Sábado";
            }
            else
            {
                nome = "Dia Inválido";
            }

            Console.WriteLine("O dia escolhido foi: {0}.", nome);

            Console.ReadLine();

        }
    }
}
