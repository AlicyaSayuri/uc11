﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade_cadastro_de_usuário__design_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sucesso", "Cadastro");
            string final;
            final = txtNome.Text     +     txtSobrenome.Text;
            lblfinal.Text = final;

            string nome;
            nome = txtNome.Text;

            string sobrenome;
            sobrenome = txtSobrenome.Text;

            string cpf;
            cpf = txtCpf.Text;

            string endereço;
            endereço = txtRuaeNumero.Text;

        }

        private void txtNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtSobrenome.Focus();
            }


        }

        private void txtSobrenome_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                txtCpf.Focus();
            }
        }

        private void txtCpf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) 
            {
                txtRuaeNumero.Focus();
            }

        }

        private void btnCadastrar_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void lblfinal_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtRuaeNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) 
            {
                btnCadastrar.Focus();
            }
        }
    }
}
