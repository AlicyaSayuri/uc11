﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCdastraLivro = new System.Windows.Forms.Label();
            this.lblNomeLivro = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblPrecoLivro = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblDataPub = new System.Windows.Forms.Label();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.cmbIDAutor = new System.Windows.Forms.ComboBox();
            this.cmbIDEditora = new System.Windows.Forms.ComboBox();
            this.dtpDataPub = new System.Windows.Forms.DateTimePicker();
            this.txtNomeLivro = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.txtPrecoLivro = new System.Windows.Forms.TextBox();
            this.btnCadastraLivro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCdastraLivro
            // 
            this.lblCdastraLivro.AutoSize = true;
            this.lblCdastraLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCdastraLivro.ForeColor = System.Drawing.Color.RosyBrown;
            this.lblCdastraLivro.Location = new System.Drawing.Point(174, 23);
            this.lblCdastraLivro.Name = "lblCdastraLivro";
            this.lblCdastraLivro.Size = new System.Drawing.Size(372, 16);
            this.lblCdastraLivro.TabIndex = 0;
            this.lblCdastraLivro.Text = "Preencha os campos abaixo para cadastrar um livro:";
            // 
            // lblNomeLivro
            // 
            this.lblNomeLivro.AutoSize = true;
            this.lblNomeLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeLivro.Location = new System.Drawing.Point(71, 88);
            this.lblNomeLivro.Name = "lblNomeLivro";
            this.lblNomeLivro.Size = new System.Drawing.Size(108, 16);
            this.lblNomeLivro.TabIndex = 1;
            this.lblNomeLivro.Text = "Nome do Livro";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAutor.Location = new System.Drawing.Point(71, 174);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(110, 16);
            this.lblNomeAutor.TabIndex = 2;
            this.lblNomeAutor.Text = "Nome do Autor";
            // 
            // lblPrecoLivro
            // 
            this.lblPrecoLivro.AutoSize = true;
            this.lblPrecoLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoLivro.Location = new System.Drawing.Point(71, 253);
            this.lblPrecoLivro.Name = "lblPrecoLivro";
            this.lblPrecoLivro.Size = new System.Drawing.Size(108, 16);
            this.lblPrecoLivro.TabIndex = 3;
            this.lblPrecoLivro.Text = "Preço do Livro";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblISBN.Location = new System.Drawing.Point(71, 133);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(42, 16);
            this.lblISBN.TabIndex = 4;
            this.lblISBN.Text = "ISBN";
            // 
            // lblDataPub
            // 
            this.lblDataPub.AutoSize = true;
            this.lblDataPub.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataPub.Location = new System.Drawing.Point(71, 215);
            this.lblDataPub.Name = "lblDataPub";
            this.lblDataPub.Size = new System.Drawing.Size(144, 16);
            this.lblDataPub.TabIndex = 5;
            this.lblDataPub.Text = "Data de Publicação";
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeEditora.Location = new System.Drawing.Point(71, 292);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(124, 16);
            this.lblNomeEditora.TabIndex = 6;
            this.lblNomeEditora.Text = "Nome da Editora";
            // 
            // cmbIDAutor
            // 
            this.cmbIDAutor.FormattingEnabled = true;
            this.cmbIDAutor.Location = new System.Drawing.Point(225, 173);
            this.cmbIDAutor.Name = "cmbIDAutor";
            this.cmbIDAutor.Size = new System.Drawing.Size(178, 21);
            this.cmbIDAutor.TabIndex = 7;
            // 
            // cmbIDEditora
            // 
            this.cmbIDEditora.FormattingEnabled = true;
            this.cmbIDEditora.Location = new System.Drawing.Point(225, 287);
            this.cmbIDEditora.Name = "cmbIDEditora";
            this.cmbIDEditora.Size = new System.Drawing.Size(178, 21);
            this.cmbIDEditora.TabIndex = 8;
            // 
            // dtpDataPub
            // 
            this.dtpDataPub.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataPub.Location = new System.Drawing.Point(225, 215);
            this.dtpDataPub.Name = "dtpDataPub";
            this.dtpDataPub.Size = new System.Drawing.Size(165, 20);
            this.dtpDataPub.TabIndex = 9;
            // 
            // txtNomeLivro
            // 
            this.txtNomeLivro.Location = new System.Drawing.Point(225, 87);
            this.txtNomeLivro.Name = "txtNomeLivro";
            this.txtNomeLivro.Size = new System.Drawing.Size(178, 20);
            this.txtNomeLivro.TabIndex = 10;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(225, 129);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(100, 20);
            this.txtISBN.TabIndex = 11;
            // 
            // txtPrecoLivro
            // 
            this.txtPrecoLivro.Location = new System.Drawing.Point(225, 253);
            this.txtPrecoLivro.Name = "txtPrecoLivro";
            this.txtPrecoLivro.Size = new System.Drawing.Size(100, 20);
            this.txtPrecoLivro.TabIndex = 12;
            // 
            // btnCadastraLivro
            // 
            this.btnCadastraLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastraLivro.Location = new System.Drawing.Point(177, 344);
            this.btnCadastraLivro.Name = "btnCadastraLivro";
            this.btnCadastraLivro.Size = new System.Drawing.Size(96, 48);
            this.btnCadastraLivro.TabIndex = 13;
            this.btnCadastraLivro.Text = "Cadastrar Livro";
            this.btnCadastraLivro.UseVisualStyleBackColor = true;
            // 
            // CadastraLivros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCadastraLivro);
            this.Controls.Add(this.txtPrecoLivro);
            this.Controls.Add(this.txtISBN);
            this.Controls.Add(this.txtNomeLivro);
            this.Controls.Add(this.dtpDataPub);
            this.Controls.Add(this.cmbIDEditora);
            this.Controls.Add(this.cmbIDAutor);
            this.Controls.Add(this.lblNomeEditora);
            this.Controls.Add(this.lblDataPub);
            this.Controls.Add(this.lblISBN);
            this.Controls.Add(this.lblPrecoLivro);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.lblNomeLivro);
            this.Controls.Add(this.lblCdastraLivro);
            this.Name = "CadastraLivros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Livros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCdastraLivro;
        private System.Windows.Forms.Label lblNomeLivro;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblPrecoLivro;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Label lblDataPub;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.ComboBox cmbIDAutor;
        private System.Windows.Forms.ComboBox cmbIDEditora;
        private System.Windows.Forms.DateTimePicker dtpDataPub;
        private System.Windows.Forms.TextBox txtNomeLivro;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.TextBox txtPrecoLivro;
        private System.Windows.Forms.Button btnCadastraLivro;
    }
}