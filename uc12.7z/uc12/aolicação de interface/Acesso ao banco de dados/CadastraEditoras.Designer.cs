﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraEditoras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCadastraEditora = new System.Windows.Forms.Label();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.txtEditora = new System.Windows.Forms.TextBox();
            this.btnCadastrarEditora = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCadastraEditora
            // 
            this.lblCadastraEditora.AutoSize = true;
            this.lblCadastraEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastraEditora.ForeColor = System.Drawing.Color.RosyBrown;
            this.lblCadastraEditora.Location = new System.Drawing.Point(188, 32);
            this.lblCadastraEditora.Name = "lblCadastraEditora";
            this.lblCadastraEditora.Size = new System.Drawing.Size(340, 16);
            this.lblCadastraEditora.TabIndex = 0;
            this.lblCadastraEditora.Text = "Digite abaixo o nome da Editora para cadastrar:";
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeEditora.Location = new System.Drawing.Point(83, 144);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(124, 16);
            this.lblNomeEditora.TabIndex = 1;
            this.lblNomeEditora.Text = "Nome da Editora";
            // 
            // txtEditora
            // 
            this.txtEditora.Location = new System.Drawing.Point(250, 140);
            this.txtEditora.Name = "txtEditora";
            this.txtEditora.Size = new System.Drawing.Size(179, 20);
            this.txtEditora.TabIndex = 2;
            // 
            // btnCadastrarEditora
            // 
            this.btnCadastrarEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarEditora.Location = new System.Drawing.Point(178, 198);
            this.btnCadastrarEditora.Name = "btnCadastrarEditora";
            this.btnCadastrarEditora.Size = new System.Drawing.Size(108, 47);
            this.btnCadastrarEditora.TabIndex = 3;
            this.btnCadastrarEditora.Text = "Cadastrar Editora";
            this.btnCadastrarEditora.UseVisualStyleBackColor = true;
            // 
            // CadastraEditoras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCadastrarEditora);
            this.Controls.Add(this.txtEditora);
            this.Controls.Add(this.lblNomeEditora);
            this.Controls.Add(this.lblCadastraEditora);
            this.Name = "CadastraEditoras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Editoras";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCadastraEditora;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.TextBox txtEditora;
        private System.Windows.Forms.Button btnCadastrarEditora;
    }
}