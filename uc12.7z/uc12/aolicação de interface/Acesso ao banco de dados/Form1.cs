﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_ao_banco_de_dados
{
    public partial class Form1 : Form
       
    {
        public string consulta;
        public string sql;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtCodLivro_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Carrega Combobox com método da classe CarregaComboBox e listas:
            consulta = "SELECT Nome_Livro FROM tbl_livro";
            CarregaComboBox carregaLivros = new CarregaComboBox();

            // Criar objeto de lista para armazenar os dados dos livros:
            List<string> Livros = new List<string>();
            Livros.AddRange(carregaLivros.carregaComboBox(consulta, "Nome_Livro"));

            // Copia dados da lista para o combobox:
            cmbLivros.Items.AddRange(Livros.ToArray());
        }

        private void bntConsulta_Click(object sender, EventArgs e)
        {
            // Consulta a ser realizada: 
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub, A.Nome_Autor FROM tbl_livro AS L INNER JOIN tbl_autores AS A ON L.ID_autor = A.ID_Autor WHERE ID_Livro = " + txtCodLivro.Text;

            // Instanciar classe que realiza a consulta:
            ConsultarLivro consultarLivros = new ConsultarLivro();

            // Passar a string SQL para o método fazerConsulta()
            consultarLivros.fazerConsulta(consulta);

            // Mostrar os resultados nas caixas de texto.
            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");


        }

        private void cmbLivros_SelectedIndexChanged(object sender, EventArgs e)
        {
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub, A.Nome_Autor FROM tbl_livro AS L INNER JOIN tbl_autores AS A ON L.ID_autor = A.ID_Autor WHERE L.Nome_Livro = '" + cmbLivros.SelectedItem.ToString() + "'";
            // Passa a string SQL para o metodo fazerConsulta:
            ConsultarLivro consultarLivro = new ConsultarLivro();
            consultarLivro.fazerConsulta(consulta);
            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");
        }

        private void consultaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
