﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraAutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCadastroAutor = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblSobrenomeAutor = new System.Windows.Forms.Label();
            this.txtNomeAutor = new System.Windows.Forms.TextBox();
            this.txtSobrenomeAutor = new System.Windows.Forms.TextBox();
            this.btnCadastraAutor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCadastroAutor
            // 
            this.lblCadastroAutor.AutoSize = true;
            this.lblCadastroAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastroAutor.ForeColor = System.Drawing.Color.RosyBrown;
            this.lblCadastroAutor.Location = new System.Drawing.Point(87, 21);
            this.lblCadastroAutor.Name = "lblCadastroAutor";
            this.lblCadastroAutor.Size = new System.Drawing.Size(560, 16);
            this.lblCadastroAutor.TabIndex = 1;
            this.lblCadastroAutor.Text = "Preencha os campos abaixo e clique em \"Cadastrar\" para inserir um novo autor.";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAutor.Location = new System.Drawing.Point(51, 84);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(110, 16);
            this.lblNomeAutor.TabIndex = 2;
            this.lblNomeAutor.Text = "Nome do Autor";
            // 
            // lblSobrenomeAutor
            // 
            this.lblSobrenomeAutor.AutoSize = true;
            this.lblSobrenomeAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobrenomeAutor.Location = new System.Drawing.Point(51, 155);
            this.lblSobrenomeAutor.Name = "lblSobrenomeAutor";
            this.lblSobrenomeAutor.Size = new System.Drawing.Size(127, 16);
            this.lblSobrenomeAutor.TabIndex = 3;
            this.lblSobrenomeAutor.Text = "Sobrenome Autor";
            // 
            // txtNomeAutor
            // 
            this.txtNomeAutor.Location = new System.Drawing.Point(205, 83);
            this.txtNomeAutor.Name = "txtNomeAutor";
            this.txtNomeAutor.Size = new System.Drawing.Size(100, 20);
            this.txtNomeAutor.TabIndex = 4;
            // 
            // txtSobrenomeAutor
            // 
            this.txtSobrenomeAutor.Location = new System.Drawing.Point(205, 154);
            this.txtSobrenomeAutor.Name = "txtSobrenomeAutor";
            this.txtSobrenomeAutor.Size = new System.Drawing.Size(100, 20);
            this.txtSobrenomeAutor.TabIndex = 5;
            // 
            // btnCadastraAutor
            // 
            this.btnCadastraAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastraAutor.Location = new System.Drawing.Point(148, 209);
            this.btnCadastraAutor.Name = "btnCadastraAutor";
            this.btnCadastraAutor.Size = new System.Drawing.Size(104, 42);
            this.btnCadastraAutor.TabIndex = 6;
            this.btnCadastraAutor.Text = "Cadastrar Autor";
            this.btnCadastraAutor.UseVisualStyleBackColor = true;
            // 
            // CadastraAutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCadastraAutor);
            this.Controls.Add(this.txtSobrenomeAutor);
            this.Controls.Add(this.txtNomeAutor);
            this.Controls.Add(this.lblSobrenomeAutor);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.lblCadastroAutor);
            this.Name = "CadastraAutor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Autores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCadastroAutor;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblSobrenomeAutor;
        private System.Windows.Forms.TextBox txtNomeAutor;
        private System.Windows.Forms.TextBox txtSobrenomeAutor;
        private System.Windows.Forms.Button btnCadastraAutor;
    }
}