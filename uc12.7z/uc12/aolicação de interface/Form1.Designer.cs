﻿namespace aolicação_de_interface
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTexto = new System.Windows.Forms.Label();
            this.btnMensagem = new System.Windows.Forms.Button();
            this.txtMensagem = new System.Windows.Forms.TextBox();
            this.txtMensagem02 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblTexto.Location = new System.Drawing.Point(376, 9);
            this.lblTexto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(248, 18);
            this.lblTexto.TabIndex = 0;
            this.lblTexto.Text = "Aplicação Gráficas do Windows";
            this.lblTexto.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnMensagem
            // 
            this.btnMensagem.BackColor = System.Drawing.Color.Azure;
            this.btnMensagem.Font = new System.Drawing.Font("Univers 55", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMensagem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMensagem.Location = new System.Drawing.Point(231, 107);
            this.btnMensagem.Name = "btnMensagem";
            this.btnMensagem.Size = new System.Drawing.Size(103, 48);
            this.btnMensagem.TabIndex = 1;
            this.btnMensagem.Text = "Clique em Mim!";
            this.btnMensagem.UseVisualStyleBackColor = false;
            this.btnMensagem.Click += new System.EventHandler(this.btnMensagem_Click);
            // 
            // txtMensagem
            // 
            this.txtMensagem.Location = new System.Drawing.Point(210, 51);
            this.txtMensagem.Name = "txtMensagem";
            this.txtMensagem.Size = new System.Drawing.Size(143, 22);
            this.txtMensagem.TabIndex = 2;
            this.txtMensagem.TextChanged += new System.EventHandler(this.txtMensagem_TextChanged);
            // 
            // txtMensagem02
            // 
            this.txtMensagem02.Location = new System.Drawing.Point(210, 187);
            this.txtMensagem02.Name = "txtMensagem02";
            this.txtMensagem02.Size = new System.Drawing.Size(153, 22);
            this.txtMensagem02.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1029, 554);
            this.Controls.Add(this.txtMensagem02);
            this.Controls.Add(this.txtMensagem);
            this.Controls.Add(this.btnMensagem);
            this.Controls.Add(this.lblTexto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Button btnMensagem;
        private System.Windows.Forms.TextBox txtMensagem;
        private System.Windows.Forms.TextBox txtMensagem02;
    }
}

