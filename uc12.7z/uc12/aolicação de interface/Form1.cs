﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aolicação_de_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnMensagem_Click(object sender, EventArgs e)
        {
            string texto;
            texto = txtMensagem.Text;
            txtMensagem02.Text = texto;
            


        }

        private void txtMensagem_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
