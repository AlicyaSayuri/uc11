﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laço_de_repetição__while_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Laço While ("enquanto")
            int i = 1;

            while (i <= 100) 
            {
                Console.WriteLine(i.ToString());
                i++;
            }

            Console.ReadLine();
        }
    }
}
