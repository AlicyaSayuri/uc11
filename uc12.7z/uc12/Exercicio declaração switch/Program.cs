﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_declaração_switch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string fruta;

            Console.WriteLine("Digite o nome de uma fruta: ");
            fruta = Console.ReadLine().ToLower();
            switch (fruta)
            {
                case "acerola":
                    Console.WriteLine("Tem bastante vitamina C!");
                    break;
                case "banana":
                    Console.WriteLine("Boa pra fazer vitamina");
                    break;
                case "caju":
                    Console.WriteLine("Essa é boa pra fazer suco");
                    break;
                case "morango":
                    Console.WriteLine("Com chantilly é uma delícia");
                    break;
                case "uva":
                    Console.WriteLine("Se fermentar fica demais");
                    break;
                default:
                    Console.WriteLine("Fruta em falta");
                    break;
            }
            Console.ReadLine();
        }
    }
}
