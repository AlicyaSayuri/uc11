﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Exercicio
            string Nome, Sobrenome, EstadoCivil;
            int Idade;
            decimal Salario;

            Console.WriteLine("--Programa para inserir seus dados no relatorio--");
            Console.Write("Digite seu nome: ");
            Nome = Console.ReadLine();

            Console.Write("Digite seu sobrenome: ");
            Sobrenome = Console.ReadLine();

            Console.Write("Digite sua idade: ");
            Idade = Convert.ToInt32(Console.ReadLine());

            Console.Write("Digite seu Estado Civil: ");
            EstadoCivil = Console.ReadLine();

            Console.Write("Digite seu Salario: ");
            Salario = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("-------RELATÓRIO DE PARTICIPANTE-------");
            Console.BackgroundColor = ConsoleColor.Green;
            //Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Nome completo: {0}{1}", Nome, Sobrenome);
            Console.ResetColor();
            Console.WriteLine("Com {0} anos você está {1} e ganha R$ {2} por mês", Idade, EstadoCivil, Salario);
            Console.WriteLine("----------FIM DO RELÁTORIO----------");
            Console.ReadLine();
                }
    }
}
