﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox_e_ListBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // flag para botão que adiciona items inseridos pelo usuário
        int flag = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] bichos = new string[] { "Gato", "Cão", "Papagaio", "Lontra", "Golfinho", "Foca", "Tatu" };
            cmbAnimais.Items.Add("Águia");
            cmbAnimais.Items.Add("Baleia");
            cmbAnimais.Items.Add("Tamanduá");
            cmbAnimais.Items.Add("Carpa");
            cmbAnimais.Items.AddRange(bichos); 
        }

        private void btnGeraNovaLista_Click(object sender, EventArgs e)
        {
            cmbAnimais.Items.Clear();
            cmbAnimais.Text = string.Empty; //Limpa item que resta exibido no combobox

            string[] lugares = new string[7] { "São Paulo", "Londres", "Montreal", "Roma", "Buenos Aires", "Berlim", "Amsterdam" };
            cmbAnimais.Items.AddRange(lugares);
            flag = 0;
        }

        private void btnAdicionaItem_Click(object sender, EventArgs e)
        {
            if (flag == 0)
            {
                //Limpa lista para adicionar itens do usuário:
                cmbAnimais.Items.Clear();
                cmbAnimais.Text = String.Empty;

                //Sinal para indicar se a lista deve ser limpa ou não
                flag = 1;

                //Adicione item
                cmbAnimais.Items.Add(txtItens.Text);
                txtItens.Text = String.Empty;
                txtItens.Focus();

            }
            else 
            {
                //Adiciona item
                cmbAnimais.Items.Add(txtItens.Text);
                txtItens.Text = String.Empty;
                txtItens.Focus();
            }

        }

        private void cmbAnimais_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstAnimais.Items.Add(cmbAnimais.SelectedItem);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstAnimais.Items.Clear();
        }

        private void bntRemoverSelecionado_Click(object sender, EventArgs e)
        {
            for (int i = lstAnimais.SelectedIndices.Count - 1; i >= 0; i--) 
            {
                lstAnimais.Items.RemoveAt(lstAnimais.SelectedIndices[i]);
            }
        }

        private void bntClassificar_Click(object sender, EventArgs e)
        {
            lstAnimais.Sorted = true;
        }

        private void bntDeselecioar_Click(object sender, EventArgs e)
        {
            for (int x = 0; x < lstAnimais.Items.Count; x++) 
            {
                lstAnimais.SetSelected(x, false);
            }
            
            // Outra forma:
            // lstAnimais.ClearSelectd();
        }

        private void bntSelecionarTudo_Click(object sender, EventArgs e)
        {
            //Selecionar todos os itens da ListBox de uma vez:
            lstAnimais.BeginUpdate();
            for (int x = 0; x < lstAnimais.Items.Count; x++) 
            {
                lstAnimais.SetSelected(x, true);
            }
            lstAnimais.EndUpdate();
        }

        private void btnGerarNumeros_Click(object sender, EventArgs e)
        {
            // tryparse = tenta converter para inteiro
            int limite;
            bool eNumero = int.TryParse(txtNumeros.Text, out limite);
            if (eNumero)
            {
                lstNumeros.Items.Clear();
                for (int a = 1; a <= limite; a++)
                {
                    lstNumeros.Items.Add(a);
                }
            }
            else 
            {
                MessageBox.Show("Digite um número!", "Valor inválido");
                txtNumeros.Focus();

            }

        }

        private void lstAnimais_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
