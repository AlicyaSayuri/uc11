﻿namespace ComboBox_e_ListBox
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAdiciona = new System.Windows.Forms.Label();
            this.cmbAnimais = new System.Windows.Forms.ComboBox();
            this.btnGeraNovaLista = new System.Windows.Forms.Button();
            this.txtItens = new System.Windows.Forms.TextBox();
            this.btnAdicionaItem = new System.Windows.Forms.Button();
            this.lstAnimais = new System.Windows.Forms.ListBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.bntRemoverSelecionado = new System.Windows.Forms.Button();
            this.bntClassificar = new System.Windows.Forms.Button();
            this.bntDeselecioar = new System.Windows.Forms.Button();
            this.bntSelecionarTudo = new System.Windows.Forms.Button();
            this.pnlGeralNumeros = new System.Windows.Forms.Panel();
            this.lstNumeros = new System.Windows.Forms.ListBox();
            this.btnGerarNumeros = new System.Windows.Forms.Button();
            this.txtNumeros = new System.Windows.Forms.TextBox();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.pnlGeralNumeros.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAdiciona
            // 
            this.lblAdiciona.AutoSize = true;
            this.lblAdiciona.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdiciona.Location = new System.Drawing.Point(22, 23);
            this.lblAdiciona.Name = "lblAdiciona";
            this.lblAdiciona.Size = new System.Drawing.Size(295, 16);
            this.lblAdiciona.TabIndex = 0;
            this.lblAdiciona.Text = "Selecione itens para adicionar ao ListBox";
            // 
            // cmbAnimais
            // 
            this.cmbAnimais.FormattingEnabled = true;
            this.cmbAnimais.Location = new System.Drawing.Point(25, 66);
            this.cmbAnimais.Name = "cmbAnimais";
            this.cmbAnimais.Size = new System.Drawing.Size(292, 21);
            this.cmbAnimais.TabIndex = 1;
            this.cmbAnimais.SelectedIndexChanged += new System.EventHandler(this.cmbAnimais_SelectedIndexChanged);
            // 
            // btnGeraNovaLista
            // 
            this.btnGeraNovaLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeraNovaLista.Location = new System.Drawing.Point(104, 107);
            this.btnGeraNovaLista.Name = "btnGeraNovaLista";
            this.btnGeraNovaLista.Size = new System.Drawing.Size(120, 47);
            this.btnGeraNovaLista.TabIndex = 2;
            this.btnGeraNovaLista.Text = "Gerar Nova Listagem";
            this.btnGeraNovaLista.UseVisualStyleBackColor = true;
            this.btnGeraNovaLista.Click += new System.EventHandler(this.btnGeraNovaLista_Click);
            // 
            // txtItens
            // 
            this.txtItens.Location = new System.Drawing.Point(25, 191);
            this.txtItens.Name = "txtItens";
            this.txtItens.Size = new System.Drawing.Size(292, 20);
            this.txtItens.TabIndex = 3;
            // 
            // btnAdicionaItem
            // 
            this.btnAdicionaItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionaItem.Location = new System.Drawing.Point(344, 162);
            this.btnAdicionaItem.Name = "btnAdicionaItem";
            this.btnAdicionaItem.Size = new System.Drawing.Size(118, 49);
            this.btnAdicionaItem.TabIndex = 4;
            this.btnAdicionaItem.Text = "Adicionar item ao ComboBox";
            this.btnAdicionaItem.UseVisualStyleBackColor = true;
            this.btnAdicionaItem.Click += new System.EventHandler(this.btnAdicionaItem_Click);
            // 
            // lstAnimais
            // 
            this.lstAnimais.FormattingEnabled = true;
            this.lstAnimais.Location = new System.Drawing.Point(483, 23);
            this.lstAnimais.Name = "lstAnimais";
            this.lstAnimais.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstAnimais.Size = new System.Drawing.Size(202, 381);
            this.lstAnimais.TabIndex = 5;
            this.lstAnimais.SelectedIndexChanged += new System.EventHandler(this.lstAnimais_SelectedIndexChanged);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(700, 50);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(118, 50);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar Lista";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // bntRemoverSelecionado
            // 
            this.bntRemoverSelecionado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntRemoverSelecionado.Location = new System.Drawing.Point(700, 136);
            this.bntRemoverSelecionado.Name = "bntRemoverSelecionado";
            this.bntRemoverSelecionado.Size = new System.Drawing.Size(118, 50);
            this.bntRemoverSelecionado.TabIndex = 7;
            this.bntRemoverSelecionado.Text = "Remover Selecionados";
            this.bntRemoverSelecionado.UseVisualStyleBackColor = true;
            this.bntRemoverSelecionado.Click += new System.EventHandler(this.bntRemoverSelecionado_Click);
            // 
            // bntClassificar
            // 
            this.bntClassificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntClassificar.Location = new System.Drawing.Point(700, 242);
            this.bntClassificar.Name = "bntClassificar";
            this.bntClassificar.Size = new System.Drawing.Size(118, 50);
            this.bntClassificar.TabIndex = 8;
            this.bntClassificar.Text = "Classificar Lista";
            this.bntClassificar.UseVisualStyleBackColor = true;
            this.bntClassificar.Click += new System.EventHandler(this.bntClassificar_Click);
            // 
            // bntDeselecioar
            // 
            this.bntDeselecioar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bntDeselecioar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntDeselecioar.Location = new System.Drawing.Point(700, 342);
            this.bntDeselecioar.Name = "bntDeselecioar";
            this.bntDeselecioar.Size = new System.Drawing.Size(118, 50);
            this.bntDeselecioar.TabIndex = 9;
            this.bntDeselecioar.Text = "Deselecionar Itens";
            this.bntDeselecioar.UseVisualStyleBackColor = false;
            this.bntDeselecioar.Click += new System.EventHandler(this.bntDeselecioar_Click);
            // 
            // bntSelecionarTudo
            // 
            this.bntSelecionarTudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntSelecionarTudo.Location = new System.Drawing.Point(521, 430);
            this.bntSelecionarTudo.Name = "bntSelecionarTudo";
            this.bntSelecionarTudo.Size = new System.Drawing.Size(118, 50);
            this.bntSelecionarTudo.TabIndex = 10;
            this.bntSelecionarTudo.Text = "Selecionar Tudo";
            this.bntSelecionarTudo.UseVisualStyleBackColor = true;
            this.bntSelecionarTudo.Click += new System.EventHandler(this.bntSelecionarTudo_Click);
            // 
            // pnlGeralNumeros
            // 
            this.pnlGeralNumeros.Controls.Add(this.lstNumeros);
            this.pnlGeralNumeros.Controls.Add(this.btnGerarNumeros);
            this.pnlGeralNumeros.Controls.Add(this.txtNumeros);
            this.pnlGeralNumeros.Controls.Add(this.lblNumeros);
            this.pnlGeralNumeros.Location = new System.Drawing.Point(926, 23);
            this.pnlGeralNumeros.Name = "pnlGeralNumeros";
            this.pnlGeralNumeros.Size = new System.Drawing.Size(287, 519);
            this.pnlGeralNumeros.TabIndex = 11;
            // 
            // lstNumeros
            // 
            this.lstNumeros.FormattingEnabled = true;
            this.lstNumeros.Location = new System.Drawing.Point(82, 100);
            this.lstNumeros.Name = "lstNumeros";
            this.lstNumeros.Size = new System.Drawing.Size(120, 407);
            this.lstNumeros.TabIndex = 3;
            // 
            // btnGerarNumeros
            // 
            this.btnGerarNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerarNumeros.Location = new System.Drawing.Point(91, 43);
            this.btnGerarNumeros.Name = "btnGerarNumeros";
            this.btnGerarNumeros.Size = new System.Drawing.Size(92, 48);
            this.btnGerarNumeros.TabIndex = 2;
            this.btnGerarNumeros.Text = "Gerar Números";
            this.btnGerarNumeros.UseVisualStyleBackColor = true;
            this.btnGerarNumeros.Click += new System.EventHandler(this.btnGerarNumeros_Click);
            // 
            // txtNumeros
            // 
            this.txtNumeros.Location = new System.Drawing.Point(153, 15);
            this.txtNumeros.Name = "txtNumeros";
            this.txtNumeros.Size = new System.Drawing.Size(121, 20);
            this.txtNumeros.TabIndex = 1;
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.BackColor = System.Drawing.SystemColors.Control;
            this.lblNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.Location = new System.Drawing.Point(3, 15);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(134, 16);
            this.lblNumeros.TabIndex = 0;
            this.lblNumeros.Text = "Digite um Número:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1319, 591);
            this.Controls.Add(this.pnlGeralNumeros);
            this.Controls.Add(this.bntSelecionarTudo);
            this.Controls.Add(this.bntDeselecioar);
            this.Controls.Add(this.bntClassificar);
            this.Controls.Add(this.bntRemoverSelecionado);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lstAnimais);
            this.Controls.Add(this.btnAdicionaItem);
            this.Controls.Add(this.txtItens);
            this.Controls.Add(this.btnGeraNovaLista);
            this.Controls.Add(this.cmbAnimais);
            this.Controls.Add(this.lblAdiciona);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlGeralNumeros.ResumeLayout(false);
            this.pnlGeralNumeros.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAdiciona;
        private System.Windows.Forms.ComboBox cmbAnimais;
        private System.Windows.Forms.Button btnGeraNovaLista;
        private System.Windows.Forms.TextBox txtItens;
        private System.Windows.Forms.Button btnAdicionaItem;
        private System.Windows.Forms.ListBox lstAnimais;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button bntRemoverSelecionado;
        private System.Windows.Forms.Button bntClassificar;
        private System.Windows.Forms.Button bntDeselecioar;
        private System.Windows.Forms.Button bntSelecionarTudo;
        private System.Windows.Forms.Panel pnlGeralNumeros;
        private System.Windows.Forms.Button btnGerarNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.ListBox lstNumeros;
    }
}

