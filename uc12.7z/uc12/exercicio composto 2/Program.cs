﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_composto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string Nome;
            int Idade;
            int num2 = 65;

            Console.WriteLine("Digite seu nome: ");
            Nome = Console.ReadLine();
            Console.WriteLine("Qual sua idade: ");
            Idade = Convert.ToInt32(Console.ReadLine());

            if (Idade > 18)
            {
                Console.WriteLine(" {0}, falta {1} anos para você se aposentar!", Nome, (num2 - Idade).ToString());
            }

            else
            {
                Console.WriteLine("Você é ainda é muito novo! ");
            }

            Console.ReadLine();


        }
    }
}
