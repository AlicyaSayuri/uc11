﻿namespace Caixas_de_Listas__Radiobuttons_e_Imagens
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.bntRemoverCaractere = new System.Windows.Forms.Button();
            this.bntAdicionar = new System.Windows.Forms.Button();
            this.lstNomes = new System.Windows.Forms.ListBox();
            this.bntVerificar = new System.Windows.Forms.Button();
            this.bntLimpar = new System.Windows.Forms.Button();
            this.bntApagarItem = new System.Windows.Forms.Button();
            this.bntPreencher = new System.Windows.Forms.Button();
            this.cmbNumeros = new System.Windows.Forms.ComboBox();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.txtNumeros = new System.Windows.Forms.TextBox();
            this.bntAnimal = new System.Windows.Forms.Button();
            this.bntDesmarcar = new System.Windows.Forms.Button();
            this.bntProcurarImagem = new System.Windows.Forms.Button();
            this.gprAnimal = new System.Windows.Forms.GroupBox();
            this.radioGirafa = new System.Windows.Forms.RadioButton();
            this.radioLeao = new System.Windows.Forms.RadioButton();
            this.radioTigre = new System.Windows.Forms.RadioButton();
            this.picAnimal = new System.Windows.Forms.PictureBox();
            this.bntLimpaImagem = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gprAnimal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(12, 29);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(118, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Digite um nome:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(151, 29);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(140, 20);
            this.txtNome.TabIndex = 1;
            // 
            // bntRemoverCaractere
            // 
            this.bntRemoverCaractere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntRemoverCaractere.Location = new System.Drawing.Point(309, 15);
            this.bntRemoverCaractere.Name = "bntRemoverCaractere";
            this.bntRemoverCaractere.Size = new System.Drawing.Size(121, 47);
            this.bntRemoverCaractere.TabIndex = 2;
            this.bntRemoverCaractere.Text = "Apagar último caractere";
            this.bntRemoverCaractere.UseVisualStyleBackColor = true;
            this.bntRemoverCaractere.Click += new System.EventHandler(this.bntRemoverCaractere_Click);
            // 
            // bntAdicionar
            // 
            this.bntAdicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntAdicionar.Location = new System.Drawing.Point(171, 72);
            this.bntAdicionar.Name = "bntAdicionar";
            this.bntAdicionar.Size = new System.Drawing.Size(97, 41);
            this.bntAdicionar.TabIndex = 3;
            this.bntAdicionar.Text = "Adicionar";
            this.bntAdicionar.UseVisualStyleBackColor = true;
            this.bntAdicionar.Click += new System.EventHandler(this.bntAdicionar_Click);
            // 
            // lstNomes
            // 
            this.lstNomes.FormattingEnabled = true;
            this.lstNomes.Location = new System.Drawing.Point(151, 128);
            this.lstNomes.Name = "lstNomes";
            this.lstNomes.Size = new System.Drawing.Size(140, 121);
            this.lstNomes.TabIndex = 4;
            // 
            // bntVerificar
            // 
            this.bntVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntVerificar.Location = new System.Drawing.Point(309, 155);
            this.bntVerificar.Name = "bntVerificar";
            this.bntVerificar.Size = new System.Drawing.Size(107, 41);
            this.bntVerificar.TabIndex = 5;
            this.bntVerificar.Text = "Verificar";
            this.bntVerificar.UseVisualStyleBackColor = true;
            this.bntVerificar.Click += new System.EventHandler(this.bntVerificar_Click);
            // 
            // bntLimpar
            // 
            this.bntLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntLimpar.Location = new System.Drawing.Point(171, 269);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(97, 38);
            this.bntLimpar.TabIndex = 6;
            this.bntLimpar.Text = "Limpar";
            this.bntLimpar.UseVisualStyleBackColor = true;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // bntApagarItem
            // 
            this.bntApagarItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntApagarItem.Location = new System.Drawing.Point(171, 334);
            this.bntApagarItem.Name = "bntApagarItem";
            this.bntApagarItem.Size = new System.Drawing.Size(97, 41);
            this.bntApagarItem.TabIndex = 7;
            this.bntApagarItem.Text = "Apagar Item";
            this.bntApagarItem.UseVisualStyleBackColor = true;
            this.bntApagarItem.Click += new System.EventHandler(this.bntApagarItem_Click);
            // 
            // bntPreencher
            // 
            this.bntPreencher.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntPreencher.Location = new System.Drawing.Point(504, 29);
            this.bntPreencher.Name = "bntPreencher";
            this.bntPreencher.Size = new System.Drawing.Size(117, 47);
            this.bntPreencher.TabIndex = 8;
            this.bntPreencher.Text = "Preencher ComboBox";
            this.bntPreencher.UseVisualStyleBackColor = true;
            this.bntPreencher.Click += new System.EventHandler(this.bntPreencher_Click);
            // 
            // cmbNumeros
            // 
            this.cmbNumeros.FormattingEnabled = true;
            this.cmbNumeros.Location = new System.Drawing.Point(504, 92);
            this.cmbNumeros.Name = "cmbNumeros";
            this.cmbNumeros.Size = new System.Drawing.Size(117, 21);
            this.cmbNumeros.TabIndex = 9;
            this.cmbNumeros.SelectedIndexChanged += new System.EventHandler(this.cmbNumeros_SelectedIndexChanged);
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.Location = new System.Drawing.Point(660, 29);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(157, 16);
            this.lblNumeros.TabIndex = 10;
            this.lblNumeros.Text = "Número Selecionado:";
            // 
            // txtNumeros
            // 
            this.txtNumeros.Location = new System.Drawing.Point(686, 56);
            this.txtNumeros.Name = "txtNumeros";
            this.txtNumeros.Size = new System.Drawing.Size(100, 20);
            this.txtNumeros.TabIndex = 11;
            this.txtNumeros.TextChanged += new System.EventHandler(this.txtNumeros_TextChanged);
            // 
            // bntAnimal
            // 
            this.bntAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntAnimal.Location = new System.Drawing.Point(710, 155);
            this.bntAnimal.Name = "bntAnimal";
            this.bntAnimal.Size = new System.Drawing.Size(105, 41);
            this.bntAnimal.TabIndex = 12;
            this.bntAnimal.Text = "Escolha Animal";
            this.bntAnimal.UseVisualStyleBackColor = true;
            this.bntAnimal.Click += new System.EventHandler(this.bntAnimal_Click);
            // 
            // bntDesmarcar
            // 
            this.bntDesmarcar.Enabled = false;
            this.bntDesmarcar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntDesmarcar.Location = new System.Drawing.Point(710, 303);
            this.bntDesmarcar.Name = "bntDesmarcar";
            this.bntDesmarcar.Size = new System.Drawing.Size(105, 41);
            this.bntDesmarcar.TabIndex = 13;
            this.bntDesmarcar.Text = "Desmarcar Opções";
            this.bntDesmarcar.UseVisualStyleBackColor = true;
            this.bntDesmarcar.Click += new System.EventHandler(this.bntDesmarcar_Click);
            // 
            // bntProcurarImagem
            // 
            this.bntProcurarImagem.Enabled = false;
            this.bntProcurarImagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntProcurarImagem.Location = new System.Drawing.Point(823, 472);
            this.bntProcurarImagem.Name = "bntProcurarImagem";
            this.bntProcurarImagem.Size = new System.Drawing.Size(107, 56);
            this.bntProcurarImagem.TabIndex = 14;
            this.bntProcurarImagem.Text = "Selecionar Imagem do PC...";
            this.bntProcurarImagem.UseVisualStyleBackColor = true;
            this.bntProcurarImagem.Click += new System.EventHandler(this.bntProcurarImagem_Click);
            // 
            // gprAnimal
            // 
            this.gprAnimal.Controls.Add(this.radioTigre);
            this.gprAnimal.Controls.Add(this.radioLeao);
            this.gprAnimal.Controls.Add(this.radioGirafa);
            this.gprAnimal.Location = new System.Drawing.Point(486, 155);
            this.gprAnimal.Name = "gprAnimal";
            this.gprAnimal.Size = new System.Drawing.Size(200, 204);
            this.gprAnimal.TabIndex = 15;
            this.gprAnimal.TabStop = false;
            this.gprAnimal.Text = "Animal";
            // 
            // radioGirafa
            // 
            this.radioGirafa.AutoSize = true;
            this.radioGirafa.Location = new System.Drawing.Point(18, 24);
            this.radioGirafa.Name = "radioGirafa";
            this.radioGirafa.Size = new System.Drawing.Size(53, 17);
            this.radioGirafa.TabIndex = 0;
            this.radioGirafa.TabStop = true;
            this.radioGirafa.Text = "Girafa";
            this.radioGirafa.UseVisualStyleBackColor = true;
            // 
            // radioLeao
            // 
            this.radioLeao.AutoSize = true;
            this.radioLeao.Location = new System.Drawing.Point(18, 87);
            this.radioLeao.Name = "radioLeao";
            this.radioLeao.Size = new System.Drawing.Size(49, 17);
            this.radioLeao.TabIndex = 1;
            this.radioLeao.TabStop = true;
            this.radioLeao.Text = "Leão";
            this.radioLeao.UseVisualStyleBackColor = true;
            // 
            // radioTigre
            // 
            this.radioTigre.AutoSize = true;
            this.radioTigre.Location = new System.Drawing.Point(18, 148);
            this.radioTigre.Name = "radioTigre";
            this.radioTigre.Size = new System.Drawing.Size(49, 17);
            this.radioTigre.TabIndex = 2;
            this.radioTigre.TabStop = true;
            this.radioTigre.Text = "Tigre";
            this.radioTigre.UseVisualStyleBackColor = true;
            // 
            // picAnimal
            // 
            this.picAnimal.Location = new System.Drawing.Point(486, 365);
            this.picAnimal.Name = "picAnimal";
            this.picAnimal.Size = new System.Drawing.Size(331, 163);
            this.picAnimal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAnimal.TabIndex = 16;
            this.picAnimal.TabStop = false;
            // 
            // bntLimpaImagem
            // 
            this.bntLimpaImagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntLimpaImagem.Location = new System.Drawing.Point(712, 230);
            this.bntLimpaImagem.Name = "bntLimpaImagem";
            this.bntLimpaImagem.Size = new System.Drawing.Size(105, 41);
            this.bntLimpaImagem.TabIndex = 17;
            this.bntLimpaImagem.Text = "Limpar Imagem";
            this.bntLimpaImagem.UseVisualStyleBackColor = true;
            this.bntLimpaImagem.Click += new System.EventHandler(this.bntLimpaImagem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Imagens|*.jpg";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 557);
            this.Controls.Add(this.bntLimpaImagem);
            this.Controls.Add(this.picAnimal);
            this.Controls.Add(this.gprAnimal);
            this.Controls.Add(this.bntProcurarImagem);
            this.Controls.Add(this.bntDesmarcar);
            this.Controls.Add(this.bntAnimal);
            this.Controls.Add(this.txtNumeros);
            this.Controls.Add(this.lblNumeros);
            this.Controls.Add(this.cmbNumeros);
            this.Controls.Add(this.bntPreencher);
            this.Controls.Add(this.bntApagarItem);
            this.Controls.Add(this.bntLimpar);
            this.Controls.Add(this.bntVerificar);
            this.Controls.Add(this.lstNomes);
            this.Controls.Add(this.bntAdicionar);
            this.Controls.Add(this.bntRemoverCaractere);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Caixas de Listas, Botões de Rádio e Imagens";
            this.gprAnimal.ResumeLayout(false);
            this.gprAnimal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button bntRemoverCaractere;
        private System.Windows.Forms.Button bntAdicionar;
        private System.Windows.Forms.ListBox lstNomes;
        private System.Windows.Forms.Button bntVerificar;
        private System.Windows.Forms.Button bntLimpar;
        private System.Windows.Forms.Button bntApagarItem;
        private System.Windows.Forms.Button bntPreencher;
        private System.Windows.Forms.ComboBox cmbNumeros;
        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button bntAnimal;
        private System.Windows.Forms.Button bntDesmarcar;
        private System.Windows.Forms.Button bntProcurarImagem;
        private System.Windows.Forms.GroupBox gprAnimal;
        private System.Windows.Forms.RadioButton radioTigre;
        private System.Windows.Forms.RadioButton radioLeao;
        private System.Windows.Forms.RadioButton radioGirafa;
        private System.Windows.Forms.PictureBox picAnimal;
        private System.Windows.Forms.Button bntLimpaImagem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

