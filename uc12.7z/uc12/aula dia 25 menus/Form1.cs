﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aula_dia_25_menus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bntAbrir_Click(object sender, EventArgs e)
        {
            janela Tela = new janela();
            Tela.Show();
            this.Hide();
        }

        private void carreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaFoto Tela = new TelaFoto();
            Tela.Show();
            this.WindowState = FormWindowState.Minimized;
        
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
            // Para reiniciar uma aplicação, use Application.Restart();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            janela Tela = new janela();
            Tela.Show();
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
