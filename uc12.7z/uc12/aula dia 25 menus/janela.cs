﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aula_dia_25_menus
{
    public partial class janela : Form
    {
        public janela()
        {
            InitializeComponent();
        }

        private void janela_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                // Fecha o programa se não houver mais janelas abertas
                Application.Exit();
            }
            else 
            {
                // Loop pelos forms abertos
                foreach (Form formAberto in Application.OpenForms)
                {
                    // See form1 ainda etsiver aberto, reexiba-o
                    if (formAberto is Form1) 
                    { 
                        formAberto.Show();
                        break;
                    }

                }
            }
        }
    }
}
